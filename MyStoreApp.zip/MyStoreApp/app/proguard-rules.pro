# No specific rules needed - minify disabled
