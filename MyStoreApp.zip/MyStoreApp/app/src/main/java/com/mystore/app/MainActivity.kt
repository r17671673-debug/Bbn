package com.mystore.app

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var txtCartCount: TextView

    private val barcodeLauncher = registerForActivityResult(ScanContract()) { result ->
        if (result.contents != null) {
            handleScannedBarcode(result.contents)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!Prefs.isSetupDone(this)) {
            startActivity(Intent(this, SetupActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_main)

        txtCartCount = findViewById(R.id.txtCartCount)

        findViewById<Button>(R.id.btnScan).setOnClickListener {
            startScan()
        }

        findViewById<Button>(R.id.btnCart).setOnClickListener {
            startActivity(Intent(this, CartActivity::class.java))
        }

        findViewById<Button>(R.id.btnRelink).setOnClickListener {
            startActivity(Intent(this, SetupActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        updateCartCount()
    }

    private fun updateCartCount() {
        txtCartCount.text = "عدد القطع في السلة: ${CartManager.count()} - الإجمالي: ${"%.2f".format(CartManager.total())}"
    }

    private fun startScan() {
        val options = ScanOptions()
        options.setDesiredBarcodeFormats(ScanOptions.ALL_CODE_TYPES)
        options.setPrompt("وجّه الكاميرا على الباركود")
        options.setBeepEnabled(true)
        options.setOrientationLocked(true)
        barcodeLauncher.launch(options)
    }

    private fun handleScannedBarcode(barcode: String) {
        val productsUri = Prefs.getProductsUri(this) ?: run {
            Toast.makeText(this, "ملف المنتجات غير مربوط", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                ExcelManager.findProductByBarcode(this@MainActivity, productsUri, barcode)
            }
            result.onSuccess { product ->
                if (product == null) {
                    Toast.makeText(this@MainActivity, "الباركود ده غير موجود في ملف المنتجات", Toast.LENGTH_LONG).show()
                } else {
                    showProductDialog(product)
                }
            }.onFailure { e ->
                Toast.makeText(this@MainActivity, "خطأ في قراية ملف المنتجات: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showProductDialog(product: Product) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_product, null)
        view.findViewById<TextView>(R.id.txtProductName).text = product.name
        view.findViewById<TextView>(R.id.txtOriginalPrice).text = "الأصلي: ${"%.2f".format(product.originalPrice)}"
        view.findViewById<TextView>(R.id.txtRetailPrice).text = "الفصال: ${"%.2f".format(product.retailPrice)}"
        view.findViewById<TextView>(R.id.txtWholesalePrice).text = "الجملة: ${"%.2f".format(product.wholesalePrice)}"

        val radioGroup = view.findViewById<RadioGroup>(R.id.radioPriceType)
        val edtQty = view.findViewById<EditText>(R.id.edtQuantity)
        edtQty.setText("1")

        AlertDialog.Builder(this)
            .setTitle("إضافة للسلة")
            .setView(view)
            .setPositiveButton("إضافة") { _, _ ->
                val checkedId = radioGroup.checkedRadioButtonId
                val priceType = when (checkedId) {
                    R.id.radioOriginal -> PriceType.ORIGINAL
                    R.id.radioWholesale -> PriceType.WHOLESALE
                    else -> PriceType.RETAIL
                }
                val qty = edtQty.text.toString().toIntOrNull() ?: 1
                val unitPrice = product.priceFor(priceType)
                CartManager.addItem(CartItem(product, priceType, qty, unitPrice))
                updateCartCount()
                Toast.makeText(this, "${product.name} اتضاف للسلة", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
