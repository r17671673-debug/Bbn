package com.mystore.app

data class CartItem(
    val product: Product,
    val priceType: PriceType,
    var quantity: Int,
    val unitPrice: Double
) {
    val subtotal: Double
        get() = unitPrice * quantity
}

/**
 * السلة الحالية - محفوظة في الذاكرة طول ما التطبيق شغال
 * (لسه معمول عليها بيع = يبقى ما اتخزنتش في ملف المبيعات)
 */
object CartManager {
    private val items = mutableListOf<CartItem>()

    fun addItem(item: CartItem) {
        // لو نفس المنتج بنفس نوع السعر موجود، زوّد الكمية بدل ما تضيف صف جديد
        val existing = items.find { it.product.barcode == item.product.barcode && it.priceType == item.priceType }
        if (existing != null) {
            existing.quantity += item.quantity
        } else {
            items.add(item)
        }
    }

    fun removeItem(item: CartItem) {
        items.remove(item)
    }

    fun getItems(): List<CartItem> = items.toList()

    fun total(): Double = items.sumOf { it.subtotal }

    fun count(): Int = items.sumOf { it.quantity }

    fun clear() {
        items.clear()
    }
}
