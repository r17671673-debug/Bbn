package com.mystore.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CartAdapter(
    private var items: MutableList<CartItem>,
    private val onChanged: () -> Unit
) : RecyclerView.Adapter<CartAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtName: TextView = view.findViewById(R.id.txtItemName)
        val txtDetails: TextView = view.findViewById(R.id.txtItemDetails)
        val btnRemove: Button = view.findViewById(R.id.btnRemoveItem)
    }

    fun updateItems(newItems: List<CartItem>) {
        items = newItems.toMutableList()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_cart, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.txtName.text = item.product.name
        holder.txtDetails.text = "${item.priceType.label} × ${item.quantity} = ${"%.2f".format(item.subtotal)}"
        holder.btnRemove.setOnClickListener {
            CartManager.removeItem(item)
            onChanged()
        }
    }

    override fun getItemCount(): Int = items.size
}
