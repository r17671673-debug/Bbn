package com.mystore.app

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CartActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var txtTotal: TextView
    private lateinit var adapter: CartAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        recyclerView = findViewById(R.id.recyclerCart)
        txtTotal = findViewById(R.id.txtCartTotal)

        adapter = CartAdapter(CartManager.getItems().toMutableList()) {
            refreshList()
        }
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        findViewById<Button>(R.id.btnCheckout).setOnClickListener {
            confirmCheckout()
        }

        refreshList()
    }

    private fun refreshList() {
        adapter.updateItems(CartManager.getItems())
        txtTotal.text = "الإجمالي: ${"%.2f".format(CartManager.total())} جنيه"
    }

    private fun confirmCheckout() {
        if (CartManager.getItems().isEmpty()) {
            Toast.makeText(this, "السلة فاضية", Toast.LENGTH_SHORT).show()
            return
        }

        AlertDialog.Builder(this)
            .setTitle("تأكيد البيع")
            .setMessage("هل تريد تسجيل هذه الفاتورة في ملف المبيعات؟")
            .setPositiveButton("تأكيد") { _, _ ->
                doCheckout()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun doCheckout() {
        val salesUri = Prefs.getSalesUri(this) ?: run {
            Toast.makeText(this, "ملف المبيعات غير مربوط", Toast.LENGTH_SHORT).show()
            return
        }
        val itemsSnapshot = CartManager.getItems()

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                ExcelManager.appendInvoice(this@CartActivity, salesUri, itemsSnapshot)
            }
            result.onSuccess { invoiceNumber ->
                Toast.makeText(this@CartActivity, "تم تسجيل الفاتورة رقم $invoiceNumber بنجاح", Toast.LENGTH_LONG).show()
                CartManager.clear()
                refreshList()
            }.onFailure { e ->
                Toast.makeText(this@CartActivity, "فشل تسجيل الفاتورة: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
