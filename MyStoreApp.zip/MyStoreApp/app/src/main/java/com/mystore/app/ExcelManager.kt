package com.mystore.app

import android.content.Context
import android.net.Uri
import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.ss.usermodel.CellType
import org.apache.poi.ss.usermodel.Row
import org.apache.poi.ss.usermodel.Sheet
import org.apache.poi.ss.usermodel.Workbook
import org.apache.poi.ss.usermodel.WorkbookFactory
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ExcelManager {

    // ---------- أعمدة ملف المنتجات ----------
    private const val COL_NAME = 0
    private const val COL_ORIGINAL = 1
    private const val COL_RETAIL = 2
    private const val COL_WHOLESALE = 3
    private const val COL_IMAGE = 4
    private const val COL_BARCODE = 5

    // ---------- أعمدة ملف المبيعات ----------
    private val SALES_HEADER = arrayOf(
        "التاريخ", "الوقت", "رقم الفاتورة", "اسم المنتج",
        "نوع السعر المستخدم", "سعر الوحدة", "الكمية", "الإجمالي"
    )

    /**
     * يقرا ملف المنتجات ويبحث عن باركود معين. يرجع null لو مش موجود أو حصل خطأ.
     */
    fun findProductByBarcode(context: Context, uri: Uri, barcode: String): Result<Product?> {
        return try {
            val input = context.contentResolver.openInputStream(uri)
                ?: return Result.failure(Exception("مش قادر يفتح ملف المنتجات"))
            val workbook: Workbook = input.use { WorkbookFactory.create(it) }
            val sheet: Sheet = workbook.getSheetAt(0)

            var found: Product? = null
            for (rowIndex in 0..sheet.lastRowNum) {
                val row = sheet.getRow(rowIndex) ?: continue
                val rowBarcode = cellToString(row.getCell(COL_BARCODE)).trim()
                if (rowBarcode.isEmpty()) continue
                if (rowBarcode == barcode.trim()) {
                    found = Product(
                        rowIndex = rowIndex,
                        name = cellToString(row.getCell(COL_NAME)),
                        originalPrice = cellToDouble(row.getCell(COL_ORIGINAL)),
                        retailPrice = cellToDouble(row.getCell(COL_RETAIL)),
                        wholesalePrice = cellToDouble(row.getCell(COL_WHOLESALE)),
                        imageInfo = cellToString(row.getCell(COL_IMAGE)),
                        barcode = rowBarcode
                    )
                    break
                }
            }
            workbook.close()
            Result.success(found)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * يضيف فاتورة كاملة (كل عناصر السلة) في ملف المبيعات كصفوف، وصف إجمالي في النهاية.
     * بيقرا الملف كامل الأول، يضيف الصفوف في الذاكرة، وبعدين يكتبه بالكامل تاني (overwrite).
     */
    fun appendInvoice(
        context: Context,
        uri: Uri,
        cartItems: List<CartItem>
    ): Result<String> {
        return try {
            // 1) قراية الملف الحالي (لو فاضي أو أول مرة، هنعمل ورقة جديدة بالهيدر)
            val existingBytes: ByteArray? = try {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            } catch (e: Exception) {
                null
            }

            val workbook: Workbook = if (existingBytes != null && existingBytes.isNotEmpty()) {
                WorkbookFactory.create(existingBytes.inputStream())
            } else {
                XSSFWorkbook()
            }

            val sheet: Sheet = if (workbook.numberOfSheets == 0) {
                workbook.createSheet("المبيعات")
            } else {
                workbook.getSheetAt(0)
            }

            // لو الملف فاضي تمامًا (مفيش ولا صف هيدر)، نضيف صف الهيدر الأول
            var nextRowIndex: Int
            if (sheet.physicalNumberOfRows == 0) {
                val headerRow = sheet.createRow(0)
                SALES_HEADER.forEachIndexed { i, title ->
                    headerRow.createCell(i).setCellValue(title)
                }
                nextRowIndex = 1
            } else {
                nextRowIndex = sheet.lastRowNum + 1
            }

            val now = Date()
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(now)
            val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(now)
            val invoiceNumber = "INV" + SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault()).format(now)

            var grandTotal = 0.0
            for (item in cartItems) {
                val row = sheet.createRow(nextRowIndex++)
                row.createCell(0).setCellValue(dateStr)
                row.createCell(1).setCellValue(timeStr)
                row.createCell(2).setCellValue(invoiceNumber)
                row.createCell(3).setCellValue(item.product.name)
                row.createCell(4).setCellValue(item.priceType.label)
                row.createCell(5).setCellValue(item.unitPrice)
                row.createCell(6).setCellValue(item.quantity.toDouble())
                row.createCell(7).setCellValue(item.subtotal)
                grandTotal += item.subtotal
            }

            // صف الإجمالي الكلي للفاتورة
            val totalRow = sheet.createRow(nextRowIndex)
            totalRow.createCell(2).setCellValue(invoiceNumber)
            totalRow.createCell(3).setCellValue("الإجمالي الكلي للفاتورة")
            totalRow.createCell(7).setCellValue(grandTotal)

            // 2) كتابة الملف بالكامل تاني في نفس الرابط
            val outBytes = ByteArrayOutputStream()
            workbook.write(outBytes)
            workbook.close()

            context.contentResolver.openOutputStream(uri, "wt")?.use { out ->
                out.write(outBytes.toByteArray())
                out.flush()
            } ?: return Result.failure(Exception("مش قادر يكتب في ملف المبيعات"))

            Result.success(invoiceNumber)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun cellToString(cell: Cell?): String {
        if (cell == null) return ""
        return when (cell.cellType) {
            CellType.STRING -> cell.stringCellValue.trim()
            CellType.NUMERIC -> {
                val d = cell.numericCellValue
                if (d == d.toLong().toDouble()) d.toLong().toString() else d.toString()
            }
            CellType.BOOLEAN -> cell.booleanCellValue.toString()
            CellType.FORMULA -> try {
                cell.stringCellValue.trim()
            } catch (e: Exception) {
                try { cell.numericCellValue.toString() } catch (e2: Exception) { "" }
            }
            else -> ""
        }
    }

    private fun cellToDouble(cell: Cell?): Double {
        if (cell == null) return 0.0
        return when (cell.cellType) {
            CellType.NUMERIC -> cell.numericCellValue
            CellType.STRING -> cell.stringCellValue.trim().replace(",", "").toDoubleOrNull() ?: 0.0
            else -> 0.0
        }
    }
}
