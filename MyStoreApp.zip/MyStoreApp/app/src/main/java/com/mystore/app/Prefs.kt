package com.mystore.app

import android.content.Context
import android.net.Uri

object Prefs {
    private const val PREFS_NAME = "mystore_prefs"
    private const val KEY_PRODUCTS_URI = "products_uri"
    private const val KEY_SALES_URI = "sales_uri"

    fun saveProductsUri(context: Context, uri: Uri) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_PRODUCTS_URI, uri.toString()).apply()
    }

    fun saveSalesUri(context: Context, uri: Uri) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_SALES_URI, uri.toString()).apply()
    }

    fun getProductsUri(context: Context): Uri? {
        val s = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_PRODUCTS_URI, null) ?: return null
        return Uri.parse(s)
    }

    fun getSalesUri(context: Context): Uri? {
        val s = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_SALES_URI, null) ?: return null
        return Uri.parse(s)
    }

    fun isSetupDone(context: Context): Boolean {
        return getProductsUri(context) != null && getSalesUri(context) != null
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
