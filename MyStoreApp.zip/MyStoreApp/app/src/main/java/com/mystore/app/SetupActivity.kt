package com.mystore.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class SetupActivity : AppCompatActivity() {

    private lateinit var txtProducts: TextView
    private lateinit var txtSales: TextView

    private val pickProducts = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            takePersistablePermission(uri)
            Prefs.saveProductsUri(this, uri)
            txtProducts.text = "ملف المنتجات: تم الربط ✅"
            checkDoneAndMaybeFinish()
        }
    }

    private val pickSales = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            takePersistablePermission(uri)
            Prefs.saveSalesUri(this, uri)
            txtSales.text = "ملف المبيعات: تم الربط ✅"
            checkDoneAndMaybeFinish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)

        txtProducts = findViewById(R.id.txtProductsStatus)
        txtSales = findViewById(R.id.txtSalesStatus)

        val existingProducts = Prefs.getProductsUri(this)
        val existingSales = Prefs.getSalesUri(this)
        if (existingProducts != null) txtProducts.text = "ملف المنتجات: تم الربط ✅"
        if (existingSales != null) txtSales.text = "ملف المبيعات: تم الربط ✅"

        findViewById<Button>(R.id.btnPickProducts).setOnClickListener {
            pickProducts.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "*/*"))
        }

        findViewById<Button>(R.id.btnPickSales).setOnClickListener {
            pickSales.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "*/*"))
        }

        findViewById<Button>(R.id.btnContinue).setOnClickListener {
            if (Prefs.isSetupDone(this)) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "لازم تربط الملفين الاتنين الأول", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun takePersistablePermission(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (e: Exception) {
            // بعض مزودي الملفات مش بيدعموا صلاحية دايمة - هنحاول نستخدم الرابط برضو
        }
    }

    private fun checkDoneAndMaybeFinish() {
        if (Prefs.isSetupDone(this)) {
            Toast.makeText(this, "تمام، اضغط استمرار", Toast.LENGTH_SHORT).show()
        }
    }
}
